//alert("JavaScript works!");
/*  Zachary Crosser, 
	06/28/2012, 
	Deliverable 1, 
	Average Day 
*/

var alarm_gone_off = true,
	hit_snooze = 4,
	no_more_sleep = "no more sleep"
	ready_to_get_up = "let\'s wake up"
	alarm_going_off = "I dont want to get up"
;



if (alarm_gone_off === true) {
  
  if (hit_snooze <= 5)
    console.log(alarm_going_off + ", but I have to get up");
	
	if (hit_snooze <= 5) {
		console.log("we can hit snooze " + ( 5 - hit_snooze ) + " more times");
	} else {
		console.log("wake up and get ready");
	}
	if (hit_snooze >=5) {
		console.log(ready_to_get_up)
	}

	if (hit_snooze >=5) {
		console.log(no_more_sleep)
	}

} else {
	console.log("continue sleeping");	
	}

console.log(alarm_going_off);	
console.log(alarm_gone_off);
console.log(hit_snooze);
console.log(no_more_sleep);
console.log(ready_to_get_up);